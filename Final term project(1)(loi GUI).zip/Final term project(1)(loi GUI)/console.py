import pandas as pd
import sys

sys.path.append(
    "D:\\Final term project(1)\\analysis_data_package"
)  # thêm đường dẫn package vào sys.path
# print(sys.path)
import analysis_data_package.CRUD
import analysis_data_package.data_cleaning
import analysis_data_package.data_normalization
import analysis_data_package.data_visualization
import analysis_data_package.search_function_for_console
import analysis_data_package.sort_function_for_console
import analysis_data_package.filter_function
import sys
import os

file_path = "D:\\AppleStore.csv"
my_df = pd.read_csv(file_path)
my_df = my_df.loc[:, ~my_df.columns.str.contains("^Unnamed")]

while True:
    print()
    print("0. Exit")
    print("1. Create, Read, Update, Delete")
    print("2. Data cleaning")
    print("3. Normalization")
    print("4. Visualization")
    print("5. Search")
    print("6. Sort")
    print("7. Filter")
    choice1 = int(input("Your choice: "))

    if choice1 == 0:
        break

    elif choice1 == 1:
        analysis_data_package.CRUD.console()

    elif choice1 == 2:
        analysis_data_package.data_cleaning.start_cleaning(my_df)

    elif choice1 == 3:
        analysis_data_package.data_normalization.console(my_df)

    elif choice1 == 4:
        analysis_data_package.data_visualization.console()

    elif choice1 == 5:
        analysis_data_package.search_function_for_console.console(my_df)

    elif choice1 == 6:
        analysis_data_package.sort_function_for_console.console(my_df)

    elif choice1 == 7:
        analysis_data_package.filter_function.console(my_df)

    else:
        print("ERROR!")
