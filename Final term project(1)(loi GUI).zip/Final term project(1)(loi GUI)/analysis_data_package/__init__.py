__all__ = [
    "CRUD",
    "data_cleaning",
    "data_normalization",
    "data_visualization",
    "search_function_for_console",
    "sort_function",
    "sort_function_for_console",
    "filter_function",
    "CRUD_for_GUI",
]
