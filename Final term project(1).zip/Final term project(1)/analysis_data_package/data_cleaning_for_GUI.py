import pandas as pd
import numpy as np

def check_missing_value(data):
    """Nhập vào dữ liệu là một DataFrame và xuất ra bảng các cột có giá trị null"""
    if not isinstance(data, pd.DataFrame):
        raise TypeError("Input phải là một pandas DataFrame")
    missing_values_count = data.isnull().sum()
    return missing_values_count

def fill_na_value(data):
    """Điền giá trị null trong DataFrame bằng phương pháp backfill và giá trị 0"""
    if not isinstance(data, pd.DataFrame):
        raise TypeError("Input phải là một pandas DataFrame")
    result = data.fillna(method='bfill', axis=0).fillna(0)
    return result
